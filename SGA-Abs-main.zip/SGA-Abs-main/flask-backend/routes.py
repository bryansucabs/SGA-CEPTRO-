from flask import Blueprint, render_template, request, session, redirect, url_for, flash
from flask_dance.contrib.google import make_google_blueprint, google
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, Usuario, Docente, Curso
from datetime import datetime, date

routes = Blueprint('routes', __name__)


STUDENTS = [
    {"dni":"12345678", "nombre":"Juan Pérez",    "programa":"Computación e Informática", "sexo":"Masculino", "edad":22, "telefono":"987654321", "trabaja":False, "modulo":"Módulo 3"},
    {"dni":"87654321", "nombre":"María González", "programa":"Estilismo",                  "sexo":"Femenino",  "edad":24, "telefono":"912345678", "trabaja":True,  "modulo":"Módulo 2"},
    {"dni":"11223344", "nombre":"Carlos Ruiz",    "programa":"Computación e Informática", "sexo":"Masculino", "edad":20, "telefono":"923456789", "trabaja":False, "modulo":"Módulo 1"},
    {"dni":"55667788", "nombre":"Ana López",      "programa":"Estilismo",                  "sexo":"Femenino",  "edad":23, "telefono":"934567890", "trabaja":True,  "modulo":"Módulo 4"},
    {"dni":"99887766", "nombre":"Diego Silva",    "programa":"Computación e Informática", "sexo":"Masculino", "edad":21, "telefono":"945678901", "trabaja":False, "modulo":"Módulo 2"},
]

programas_activos = [
    {"nombre":"Computación e Informática","docente":"Prof. Juan Martínez","inicio":"29/02/2024","fin":"29/08/2024","estudiantes":25,"modulo":1},
    {"nombre":"Estilismo","docente":"Prof. María López","inicio":"14/02/2024","fin":"14/07/2024","estudiantes":18,"modulo":4},
]
programas_proximos = [
    {"nombre":"Estilismo","docente":"Prof. Ana García","inicio":"31/03/2024","fin":"29/09/2024"},
]
programas_finalizados = [
    {"nombre":"Computación e Informática","docente":"Prof. Carlos Rivera","inicio":"31/08/2023","fin":"27/02/2024","estudiantes":22},
]


@routes.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        usuario = request.form['usuario']
        password = request.form['password']
        user = Usuario.query.filter_by(usuario=usuario).first()
        if user and user.password and check_password_hash(user.password, password):
            print("Usuario autenticado:", user.usuario)
            session['usuario'] = user.email
            session['rol'] = user.rol
            session['user_id'] = user.id  # <-- agrega esto si lo necesitas en otras rutas
            if user.rol == 'docente':
                docente = Docente.query.filter_by(id=user.id).first()
                session['nombre_docente'] = docente.nombre_completo if docente and docente.nombre_completo else user.usuario
            flash('Inicio de sesión exitoso', 'success')
            if user.rol == 'docente':
                return redirect(url_for('routes.inicio_docente'))
            elif user.rol == 'estudiante':
                usuario = session.get('usuario')
                print("Sesión iniciada para estudiante:", usuario)
                print("user_id en sesión:", session.get('user_id'))
                print(f"Usuario estudiante en sesión: {usuario}")
                print("Redirigiendo a React...")
                #  redirige al frontend React (en desarrollo)
                return redirect("http://localhost:5173/")
            else:
                return redirect(url_for('routes.inicio_admin'))
        else:
            flash('Usuario o contraseña incorrectos', 'error')
    return render_template('login.html')

@routes.route('/pagina_principal')
def pagina_principal():
    if 'usuario' in session:
        return f"Bienvenido {session['usuario']} ({session['rol']})"
    return redirect(url_for('login'))


@routes.route('/login_google')
def login_google():
    # Redirige a Google para la autenticación
    return redirect(url_for('google.login'))

@routes.route('/google_login/callback')
def google_login_callback():
    #if 'usuario' in session:
    #    return redirect(url_for('routes.pagina_principal'))
    
    if not google.authorized:
        return redirect(url_for('google.login'))

    resp = google.get("https://www.googleapis.com/oauth2/v3/userinfo")

    if not resp.ok:
        flash("Error al obtener la información del usuario de Google.", "error")
        return redirect(url_for('routes.login'))

    user_info = resp.json()
    print("Response google: ", user_info)

    # Verificar que Google haya enviado un email
    if 'email' not in user_info:
        flash("Google no proporcionó una dirección de correo electrónico.", "error")
        return redirect(url_for('routes.login'))

    # Solo permitir correos institucionales
    if not user_info['email'].endswith('@ucsp.edu.pe'):
        flash("Solo se permite correos institucionales","error")
        return redirect(url_for('routes.login'))

    # Obtener ID Unico de google
    google_id = user_info.get("sub")

    # Verificar si el usuario ya esta registrado
    user = Usuario.query.filter_by(email=user_info['email']).first()
    if not user:
        user = Usuario(
            usuario=user_info.get("name", "Usuario sin nombre"),
            email=user_info['email'],
            password=None,
            rol='estudiante'
        )
        db.session.add(user)
        db.session.commit()

    session['usuario'] = user.usuario
    session['rol'] = user.rol
    return redirect(url_for('routes.pagina_principal'))

@routes.route('/docente/perfil', methods=['GET','POST'])
def perfil_docente():
    if 'usuario' not in session or session.get('rol') != 'docente':
        return redirect(url_for('routes.login'))

    usuario = Usuario.query.filter_by(email=session['usuario']).first()
    docente = Docente.query.filter_by(id=usuario.id).first()
    correo_institucional = docente.usuario.email

    if request.method == 'POST':
        # Solo actualiza los campos editables por el docente
        docente.celular = request.form.get('celular')
        docente.correo_personal = request.form.get('correo_personal')
        db.session.commit()
        flash('Datos actualizados correctamente', 'success')

    return render_template('perfil_docente.html', docente=docente, usuario=usuario, correo_institucional=correo_institucional)

@routes.route('/docente/inicio')
def inicio_docente():
    if 'usuario' not in session or session.get('rol') != 'docente':
        return redirect(url_for('routes.login'))
    return render_template('inicio_docente.html')

@routes.route('/docente/cursos')
def cursos_docente():
    if 'usuario' not in session or session.get('rol') != 'docente':
        return redirect(url_for('routes.login'))
    
    docente = Docente.query.filter_by(id=session['user_id']).first()
    cursos = []
    if docente:
        from models import ProgramacionClase, Curso, Modulo, Programa, Salon
        programaciones = ProgramacionClase.query.filter_by(docente_id=docente.id).all()
        for prog in programaciones:
            curso = Curso.query.get(prog.curso_id)
            modulo = Modulo.query.get(curso.modulo_id) if curso else None
            programa = Programa.query.get(modulo.programa_id) if modulo else None
            salon = Salon.query.get(prog.salon_id) if prog.salon_id else None
            if curso:
                cursos.append({
                    "codigo": curso.id,
                    "nombre": curso.nombre,
                    "modulo": modulo.nombre if modulo else "",
                    "programa": programa.nombre if programa else "",
                    "periodo": prog.periodo_academico,
                    "dia": prog.dia_semana,
                    "hora": f"{prog.hora_inicio.strftime('%H:%M')} - {prog.hora_fin.strftime('%H:%M')}",
                    "salon": salon.nombre if salon else "",
                })
    
    return render_template('cursos_docente.html', cargas=cursos)

@routes.route('/logout')
def logout():
    session.clear()
    flash('Sesión cerrada correctamente', 'success')
    return redirect(url_for('routes.login'))

@routes.route('/docente/evaluaciones')
def evaluaciones_docente():
    from models import Docente, ProgramacionClase, Curso, Matricula, Estudiante, Calificacion

    docente_id = session.get('user_id')
    if not docente_id:
        return redirect(url_for('routes.login'))

    # Obtén los cursos asignados al docente
    programaciones = ProgramacionClase.query.filter_by(docente_id=docente_id).all()
    cursos = [Curso.query.get(p.curso_id) for p in programaciones]

    alumnos = []
    for curso in cursos:
        # Busca estudiantes matriculados en el módulo del curso
        matriculas = Matricula.query.filter_by(modulo_id=curso.modulo_id).all()
        for m in matriculas:
            estudiante = Estudiante.query.get(m.estudiante_id)
            if not estudiante:
                continue
            if estudiante.programa_estudio != curso.modulo.programa.nombre:
                continue
            notas = []
            for i in range(1, 9):
                cal = Calificacion.query.filter_by(
                    estudiante_id=estudiante.codigo,
                    curso_id=curso.id,
                    tipo_evaluacion=f"Nota {i}"
                ).first()
                notas.append(cal.valor if cal else "")
            alumnos.append({
                "codigo": estudiante.codigo,
                "curso": curso.nombre,
                "seccion": "",  # Si tienes sección, agrégala aquí
                "nombre": estudiante.nombre_completo,
                "notas": notas
            })

    return render_template('evaluaciones_docente.html', alumnos=alumnos)


@routes.route('/docente/asistencia')
def asistencia_docente():
    # Ejemplo: consulta real (ajusta según tus modelos)
    from models import ProgramacionClase, Curso, Salon, Programa, Modulo
    docente_id = session.get('user_id')
    programaciones = ProgramacionClase.query.filter_by(docente_id=docente_id).all()
    cargas = []
        
    for prog in programaciones:
        curso = Curso.query.get(prog.curso_id)
        modulo = Modulo.query.get(curso.modulo_id) if curso else None
        programa = Programa.query.get(modulo.programa_id) if modulo else None
        salon = Salon.query.get(prog.salon_id) if prog.salon_id else None

        cargas.append({
            "codigo": curso.id,
            "nombre": curso.nombre,
            "periodo": prog.periodo_academico,
            "modulo": modulo.nombre if modulo else "",
            "programa": programa.nombre if programa else "",
            "salon": salon.nombre if salon else "", 
        })
    return render_template('asistencia_docente.html', cargas=cargas)


@routes.route('/docente/curso/<int:codigo>/evaluaciones', methods=['GET', 'POST'])
def ingresar_notas(codigo):
    from models import Calificacion, Estudiante, Matricula, Curso
    from datetime import datetime

    curso = Curso.query.get(codigo)
    modulo_id = curso.modulo_id
    matriculas = Matricula.query.filter_by(modulo_id=modulo_id).all()

    # Determina la evaluación seleccionada
    if request.method == 'POST':
        evaluacion_actual = int(request.form.get("evaluacion", 1))
    else:
        evaluacion_actual = int(request.args.get("evaluacion", 1))

    estudiantes = []
    for m in matriculas:
        estudiante = Estudiante.query.get(m.estudiante_id)
        if not estudiante:
            continue
        if estudiante.programa_estudio != curso.modulo.programa.nombre:
            continue
        notas = {}
        for i in range(1, 9):
            cal = Calificacion.query.filter_by(
                estudiante_id=estudiante.codigo,
                curso_id=codigo,
                tipo_evaluacion=f"Nota {i}"
            ).first()
            notas[f"nota_{i}"] = cal.valor if cal else ""
        estudiantes.append({
            "codigo": estudiante.codigo,
            "nombre": estudiante.nombre_completo,
            **notas
        })

    if request.method == 'POST':
        for est in estudiantes:
            nota = request.form.get(f"nota_{est['codigo']}")
            if nota is not None and nota != "":
                calificacion = Calificacion.query.filter_by(
                    estudiante_id=est['codigo'],
                    curso_id=codigo,
                    tipo_evaluacion=f"Nota {evaluacion_actual}"
                ).first()
                if not calificacion:
                    calificacion = Calificacion(
                        estudiante_id=est['codigo'],
                        curso_id=codigo,
                        valor=float(nota),
                        tipo_evaluacion=f"Nota {evaluacion_actual}",
                        fecha_registro=datetime.now().date()
                    )
                    db.session.add(calificacion)
                else:
                    calificacion.valor = float(nota)
                    calificacion.fecha_registro = datetime.now().date()
        db.session.commit()
        flash("Notas guardadas correctamente", "success")
        return redirect(url_for('routes.ingresar_notas', codigo=codigo, evaluacion=evaluacion_actual))

    return render_template('ingresar_notas.html', estudiantes=estudiantes, codigo=codigo, evaluacion_actual=evaluacion_actual)


@routes.route('/docente/curso/<int:codigo>/consolidado')
def consolidado_notas(codigo):
    from models import Calificacion, Estudiante, Matricula, Curso

    curso = Curso.query.get(codigo)
    modulo_id = curso.modulo_id
    matriculas = Matricula.query.filter_by(modulo_id=modulo_id).all()
    estudiantes = []
    for m in matriculas:
        estudiante = Estudiante.query.get(m.estudiante_id)
        if not estudiante:
            continue
        if estudiante.programa_estudio != curso.modulo.programa.nombre:
            continue
            
        indicadores = []
        suma = 0
        count = 0
        for i in range(1, 9):
            cal = Calificacion.query.filter_by(
                estudiante_id=estudiante.codigo,
                curso_id=codigo,
                tipo_evaluacion=f"Nota {i}"
            ).first()
            valor = cal.valor if cal else ""
            indicadores.append(valor)
            if valor != "":
                suma += valor
                count += 1
        promedio = round(suma / count, 2) if count else ""
        estudiantes.append({
            "nombre": estudiante.nombre_completo,
            "indicadores": indicadores,
            "promedio": promedio,
            "recuperacion": "",  # Puedes calcularlo si tienes ese dato
            "nota_final": promedio  # O ajusta según tu lógica
        })

    docente = session.get('nombre_docente', 'Nombre Docente')
    return render_template('consolidado_notas.html', estudiantes=estudiantes, unidad=curso.nombre if curso else "Unidad Desconocida", docente=docente)


@routes.route('/docente/curso/<int:codigo>/estudiantes')
def ver_estudiantes(codigo):
    from models import Estudiante, Matricula, Curso

    curso = Curso.query.get(codigo)
    if not curso:
        flash("Curso no encontrado", "danger")
        return redirect(url_for('routes.cursos_docente'))

    modulo_id = curso.modulo_id
    matriculas = Matricula.query.filter_by(modulo_id=modulo_id).all()
    estudiantes = []
    for m in matriculas:
        estudiante = Estudiante.query.get(m.estudiante_id)
        if not estudiante:
            continue
        if estudiante.programa_estudio != curso.modulo.programa.nombre:
            continue
    
        estudiantes.append({
            "codigo": estudiante.codigo,
            "nombre": estudiante.nombre_completo,
            "programa": estudiante.programa_estudio,
        })
    return render_template('ver_estudiantes.html', estudiantes=estudiantes, codigo=codigo, curso_nombre=curso.nombre)


@routes.route('/docente/curso/<int:codigo>/registrar_asistencia', methods=['GET', 'POST'])
def registrar_asistencia(codigo):
    from models import Curso, Matricula, Estudiante, Asistencia
    from datetime import datetime, date

    curso = Curso.query.get(codigo)
    modulo_id = curso.modulo_id
    matriculas = Matricula.query.filter_by(modulo_id=modulo_id).all()
    estudiantes = []
    for m in matriculas:
        estudiante = Estudiante.query.get(m.estudiante_id)
        if not estudiante:
            continue
        if estudiante.programa_estudio != curso.modulo.programa.nombre:
            continue
        estudiantes.append(estudiante)

    if request.method == 'POST':
        fecha_str = request.form.get('fecha')
    else:
        fecha_str = request.args.get('fecha') or date.today().isoformat()
    fecha = datetime.strptime(fecha_str, "%Y-%m-%d").date()
    hoy = date.today()

    # Validación: no permitir fechas futuras
    if fecha > hoy:
        flash("No puedes registrar asistencia para fechas futuras.", "danger")
        #return redirect(url_for('routes.registrar_asistencia', codigo=codigo, fecha=hoy.isoformat()))

    # Diccionario para saber el estado actual de cada estudiante en esa fecha
    asistencias_dict = {}
    for estudiante in estudiantes:
        asistencia = Asistencia.query.filter_by(
            estudiante_id=estudiante.id,
            curso_id=curso.id,
            fecha=fecha
        ).first()
        asistencias_dict[estudiante.id] = asistencia.estado if asistencia else None

    # Registrar asistencia si es POST
    if request.method == 'POST':
        for estudiante in estudiantes:
            estado = request.form.get(f"asistencia_{estudiante.id}", "falta")
            asistencia = Asistencia.query.filter_by(
                estudiante_id=estudiante.id,
                curso_id=curso.id,
                fecha=fecha
            ).first()
            if asistencia:
                asistencia.estado = estado
                asistencia.justificada = False
            else:
                asistencia = Asistencia(
                    estudiante_id=estudiante.id,
                    curso_id=curso.id,
                    fecha=fecha,
                    estado=estado,
                    justificada=False
                )
                db.session.add(asistencia)
        db.session.commit()
        flash("Asistencia registrada correctamente", "success")
        return redirect(url_for('routes.registrar_asistencia', codigo=codigo, fecha=fecha_str))

    return render_template(
        'registrar_asistencia.html',
        estudiantes=estudiantes,
        codigo=codigo,
        curso_nombre=curso.nombre,
        fecha_actual=fecha_str,
        hoy=hoy.isoformat(),
        asistencias_dict=asistencias_dict
    )
    
    
@routes.route('/docente/curso/<int:codigo>/registrar_justificacion', methods=['GET', 'POST'])
def registrar_justificacion(codigo):
    from models import Asistencia, Estudiante, Curso
    from datetime import datetime

    curso = Curso.query.get(codigo)
    fecha_str = request.args.get('fecha')
    fecha = None
    faltas_info = []

    if fecha_str:
        fecha = datetime.strptime(fecha_str, "%Y-%m-%d").date()
        # Solo busca faltas de esa fecha
        faltas = Asistencia.query.filter_by(
            curso_id=curso.id,
            estado='falta',
            justificada=False,
            fecha=fecha
        ).all()
        for f in faltas:
            estudiante = Estudiante.query.get(f.estudiante_id)
            if estudiante:
                faltas_info.append({
                    "asistencia_id": f.id,
                    "codigo": estudiante.codigo,
                    "nombre": estudiante.nombre_completo,
                    "fecha": f.fecha,
                    "observacion": f.observacion or ""
                })

    if request.method == 'POST':
        codigo_estudiante = request.form.get('codigo_estudiante')
        fecha_str = request.form.get('fecha')
        observacion = request.form.get('observacion', '')

        estudiante = Estudiante.query.filter_by(codigo=codigo_estudiante).first()
        if estudiante:
            fecha = datetime.strptime(fecha_str, "%Y-%m-%d").date()
            asistencia = Asistencia.query.filter_by(
                estudiante_id=estudiante.id,
                curso_id=curso.id,
                fecha=fecha,
                estado='falta',
                justificada=False
            ).first()
            if asistencia:
                asistencia.justificada = True
                asistencia.observacion = observacion
                db.session.commit()
                flash("Falta justificada correctamente", "success")
            else:
                flash("No se encontró la falta para justificar.", "danger")
        else:
            flash("No se encontró el estudiante con ese código.", "danger")
        return redirect(url_for('routes.registrar_justificacion', codigo=codigo, fecha=fecha_str))

    return render_template(
        'registrar_justificacion.html',
        faltas=faltas_info,
        codigo=codigo,
        cursos_nombre=curso.nombre,
        fecha=fecha_str
    )

@routes.route('/docente/curso/<int:codigo>/reporte_asistencia')
def reporte_asistencia(codigo):
    from models import Curso, Estudiante, Matricula, Asistencia
    from datetime import datetime

    curso = Curso.query.get(codigo)
    modulo_id = curso.modulo_id
    matriculas = Matricula.query.filter_by(modulo_id=modulo_id).all()
    estudiantes = [
        Estudiante.query.get(m.estudiante_id)
        for m in matriculas
        if Estudiante.query.get(m.estudiante_id) and Estudiante.query.get(m.estudiante_id).programa_estudio == curso.modulo.programa.nombre
    ]

    # Obtener fechas filtradas
    fecha_inicio_str = request.args.get('fecha_inicio')
    fecha_fin_str = request.args.get('fecha_fin')
    asistencias_query = Asistencia.query.filter_by(curso_id=curso.id)
    if fecha_inicio_str:
        fecha_inicio = datetime.strptime(fecha_inicio_str, "%Y-%m-%d").date()
        asistencias_query = asistencias_query.filter(Asistencia.fecha >= fecha_inicio)
    if fecha_fin_str:
        fecha_fin = datetime.strptime(fecha_fin_str, "%Y-%m-%d").date()
        asistencias_query = asistencias_query.filter(Asistencia.fecha <= fecha_fin)

    asistencias = asistencias_query.all() if (fecha_inicio_str or fecha_fin_str) else []
    fechas = sorted(list({a.fecha for a in asistencias}))

    asistencia_dict = {e.id: {} for e in estudiantes}
    for a in asistencias:
        asistencia_dict[a.estudiante_id][a.fecha] = a.estado

    return render_template(
        'reporte_asistencia.html',
        estudiantes=estudiantes,
        fechas=fechas,
        asistencia_dict=asistencia_dict,
        curso_nombre=curso.nombre,
        codigo=codigo,
        fecha_inicio=fecha_inicio_str or "",
        fecha_fin=fecha_fin_str or ""
    )
    
    
import os
from werkzeug.utils import secure_filename

@routes.route('/docente/material_academico', methods=['GET', 'POST'])
def material_academico():
    UPLOAD_FOLDER = 'static/uploads/material_academico'
    ALLOWED_EXTENSIONS = {'pdf', 'xls', 'xlsx', 'csv', 'doc', 'docx', 'ppt', 'pptx'}

    if request.method == 'POST':
        archivo = request.files.get('archivo')
        if archivo and '.' in archivo.filename and archivo.filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS:
            filename = secure_filename(archivo.filename)
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
            ruta = os.path.join(UPLOAD_FOLDER, filename)
            archivo.save(ruta)
            flash("Archivo subido correctamente", "success")
        else:
            flash("Archivo no permitido", "danger")
        return redirect(url_for('routes.material_academico'))

    archivos = []
    if os.path.exists(UPLOAD_FOLDER):
        archivos = os.listdir(UPLOAD_FOLDER)

    return render_template(
        'material_academico.html',
        archivos=archivos
    )
    
    
@routes.route('/docente/horario')
def horario_docente():
    from models import ProgramacionClase, Curso, Salon
    docente_id = session.get('user_id')
    programaciones = ProgramacionClase.query.filter_by(docente_id=docente_id).all()
    horario = []
    for prog in programaciones:
        curso = Curso.query.get(prog.curso_id)
        salon = Salon.query.get(prog.salon_id) if prog.salon_id else None
        horario.append({
            "curso": curso.nombre if curso else "",
            "dia": prog.dia_semana,
            "hora_inicio": prog.hora_inicio.strftime('%H:%M'),
            "hora_fin": prog.hora_fin.strftime('%H:%M'),
            "salon": salon.nombre if salon else "",
            "periodo": prog.periodo_academico
        })
    return render_template('horario_docente.html', horario=horario)


@routes.route('/administrador/inicio')
def inicio_admin():
    if 'rol' in session and session['rol'] == 'administrador':
        return render_template('inicio_admin.html')
    else:
        flash('Acceso no autorizado', 'error')
        return redirect(url_for('routes.login'))

@routes.route('/administrador/dashboard')
def dashboard():
    return render_template('dashboard.html')

@routes.route('/administrador/estudiantes')
def estudiantes_admin():
    return render_template('estudiantes_admin.html',students=STUDENTS)

@routes.route('/administrador/programas')
def gestion_programas():
    stats = {
        "activos": len(programas_activos),
        "proximos": len(programas_proximos),
        "finalizados": len(programas_finalizados),
    }
    return render_template('programas_admin.html',
                           stats=stats,
                           programas_activos=programas_activos,
                           programas_proximos=programas_proximos,
                           programas_finalizados=programas_finalizados)



@routes.route('/')
def hello():
    return render_template('index.html')

