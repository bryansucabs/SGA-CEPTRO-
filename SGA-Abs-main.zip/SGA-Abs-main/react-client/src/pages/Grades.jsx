import { useState } from "react"
import { FaChevronDown, FaChevronUp } from "react-icons/fa"

/* ------------------------------------------------------------------ */
/*  Sub-fila (detalle de notas)                                        */
/* ------------------------------------------------------------------ */
function Notes({ notes }) {
  return (
    <tr className="grade-detail">
      {/* ⬅️ colSpan = 4 -- coincide con las 4 columnas de la cabecera */}
      <td colSpan={4}>
        <ul className="note-list">
          {notes.map(n => (
            <li key={n.label}>
              <span className="label">{n.label}</span>
              <span className="value">{n.value}</span>
            </li>
          ))}
        </ul>
      </td>
    </tr>
  )
}

/* ------------------------------------------------------------------ */
/*  Fila principal                                                     */
/* ------------------------------------------------------------------ */
function CourseRow({ index, course }) {
  const [open, setOpen] = useState(false)

  return (
    <>
      <tr className="grade-row">
        <td>{index + 1}</td>
        <td>{course.code}</td>
        <td>{course.name}</td>
        <td>
          <button className="grade-btn" onClick={() => setOpen(v => !v)}>
            {open ? "Ocultar" : "Ver notas"}{" "}
            {open ? <FaChevronUp /> : <FaChevronDown />}
          </button>
        </td>
      </tr>

      {open && <Notes notes={course.notes} />}
    </>
  )
}

/* ------------------------------------------------------------------ */
/*  Página completa                                                   */
/* ------------------------------------------------------------------ */
export default function Grades() {
  const [period, setPeriod] = useState("2024-II")

  const data = [
    {
      code: "AE502",
      name: "SEMINARIO EN INVESTIGACIÓN EN ADMINISTRACIÓN I",
      notes: [
        { label: "PERMANENTE 1",       value: "14.00" },
        { label: "EVALUACIÓN PARCIAL", value: "13.00" },
        { label: "PERMANENTE 2",       value: "16.00" },
        { label: "EVALUACIÓN FINAL",   value: "16.00" },
        { label: "Promedio Final",     value: "14.75" }
      ]
    },
    { code: "AE503", name: "GERENCIA DE MARKETING", notes: [] },
    { code: "AE504", name: "ANÁLISIS DE COSTOS",     notes: [] }
  ]

  return (
    <section className="grades-page">
      <h1>Calificaciones</h1>

      <div className="period-card">
        <label htmlFor="periodG">Seleccionar Período:</label>
        <select id="periodG" value={period} onChange={e => setPeriod(e.target.value)}>
          <option>2024-II</option><option>2024-I</option><option>2023-II</option>
        </select>
      </div>

      <div className="grades-wrapper">
        <table className="grades-table">
          <thead>
            <tr>
              <th>Nº</th><th>Código</th><th>Unidad Didáctica</th><th></th>
            </tr>
          </thead>
          <tbody>
            {data.map((c,i) => <CourseRow key={c.code} index={i} course={c} />)}
          </tbody>
        </table>
      </div>
    </section>
  )
}
