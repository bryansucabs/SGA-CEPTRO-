import { useState } from "react"
import { FaChevronDown, FaChevronUp } from "react-icons/fa"

/* ──────────────────────────────────────────────────────────── */
/*  Tarjeta con los datos del estudiante                       */
/* ──────────────────────────────────────────────────────────── */
function StudentCard() {
  return (
    <div className="perf-card">
      <img
        src="https://via.placeholder.com/80x100.png?text=Foto"
        alt="Foto del estudiante"
      />
      <div className="info">
        <h3>Mamani Galdos, Perla Sofía</h3>
        <p><strong>Código:</strong> 75803370</p>
        <p><strong>Programa:</strong> Administración de Empresas</p>
        <p><strong>Semestre:</strong> 6</p>
      </div>
    </div>
  )
}

/* ──────────────────────────────────────────────────────────── */
/*  Fila de la tabla (Periodo)                                 */
/* ──────────────────────────────────────────────────────────── */
function PeriodRow({ idx, period, open, toggle }) {
  return (
    <>
      <tr className="perf-row">
        <td>{idx + 1}</td>
        <td>{period.name}</td>
        <td>{period.avg}</td>
        <td>
          <button className="perf-btn" onClick={toggle}>
            {open ? "Ocultar" : "Ver detalle"}{" "}
            {open ? <FaChevronUp /> : <FaChevronDown />}
          </button>
        </td>
      </tr>

      {open && (
        <tr className="perf-detail">
          <td colSpan={4}>
            <ul className="course-list">
              {period.courses.map(c => (
                <li key={c.code}>
                  <span className="label">
                    {c.code} – {c.name}
                  </span>
                  <span className="value">{c.final}</span>
                </li>
              ))}
            </ul>
          </td>
        </tr>
      )}
    </>
  )
}

/* ──────────────────────────────────────────────────────────── */
/*  Página completa                                            */
/* ──────────────────────────────────────────────────────────── */
export default function Rendimiento() {
  const data = [
    {
      name: "2024-I",
      avg: 16.7,
      courses: [
        { code: "AE601", name: "Auditoría", final: 17 },
        { code: "AE602", name: "Plan de Marketing", final: 16 },
        { code: "AE603", name: "Gestión Presupuestaria", final: 17 }
      ]
    },
    {
      name: "2023-II",
      avg: 15.9,
      courses: [
        { code: "AE501", name: "Costos II", final: 15 },
        { code: "AE502", name: "Investigación I", final: 17 }
      ]
    }
  ]

  /*  control de filas abiertas  */
  const [openIdx, setOpenIdx] = useState(null)

  return (
    <section className="perf-page">
      <h1>Rendimiento</h1>

      {/* tarjeta estudiante */}
      <StudentCard />

      {/* tabla de periodos */}
      <div className="perf-wrapper">
        <table className="perf-table">
          <thead>
            <tr>
              <th>Nº</th>
              <th>Periodo</th>
              <th>Nota final</th>
              <th></th>
            </tr>
          </thead>

          <tbody>
            {data.map((p, i) => (
              <PeriodRow
                key={p.name}
                idx={i}
                period={p}
                open={openIdx === i}
                toggle={() => setOpenIdx(openIdx === i ? null : i)}
              />
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
