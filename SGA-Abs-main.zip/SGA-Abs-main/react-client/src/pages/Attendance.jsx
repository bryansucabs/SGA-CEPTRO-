import { useState } from "react"
import { FaChevronDown, FaChevronUp } from "react-icons/fa"

/* ------------------------------------------------------- */
/*  Fila-detalle: una fila por cada inasistencia            */
/*  (date bajo “Código”, reason bajo “Unidad Didáctica”)    */
/* ------------------------------------------------------- */
function DetailRows({ absences }) {
  return absences.length === 0 ? (
    <tr className="att-detail ok">
      {/* 7 celdas → mismas columnas de la cabecera */}
      <td></td>
      <td className="date">—</td>
      <td>✔ Sin inasistencias</td>
      <td></td><td></td><td></td><td></td>
    </tr>
  ) : (
    absences.map((a, i) => (
      <tr key={i} className="att-detail">
        <td></td>
        <td className="date">{a.date}</td>
        <td>{a.reason}</td>
        <td></td><td></td><td></td><td></td>
      </tr>
    ))
  )
}

/* ------------------------------------------------------- */
/*  Fila principal                                         */
/* ------------------------------------------------------- */
function CourseRow({ idx, item }) {
  const [open, setOpen] = useState(false)

  /* barra % inasistencias */
  const barStyle = { width: `${item.miss}%` }
  const missStyle = { width: `${item.miss}%` }

  return (
    <>
      <tr className="att-row">
        <td>{idx + 1}</td>
        <td>{item.code}</td>
        <td>{item.name}</td>
        <td>{item.sessions}</td>
        <td>{item.max}</td>
        <td>
          <div className="bar-bg">
            <div className="bar-miss" style={missStyle}></div>
            <div className="bar-label">{item.miss}%</div>
          </div>
        </td>
        <td>
          <button className="att-btn" onClick={() => setOpen(v => !v)}>
            {open ? "Ocultar" : "Ver detalle"}{" "}
            {open ? <FaChevronUp /> : <FaChevronDown />}
          </button>
        </td>
      </tr>

      {open && <DetailRows absences={item.absences} />}
    </>
  )
}

/* ------------------------------------------------------- */
/*  Página completa                                        */
/* ------------------------------------------------------- */
export default function Attendance() {
  const [period, setPeriod] = useState("2024-II")

  const data = [
    {
      code:"AE601",name:"AUDITORÍA",sessions:32,max:6,miss:3,
      absences:[{date:"14-03-2024",reason:"Falta injustificada"}]
    },
    {
      code:"AE602",name:"PLAN DE MARKETING",sessions:32,max:6,miss:0,
      absences:[]
    },
    {
      code:"AE603",name:"GESTIÓN PRESUPUESTARIA",sessions:32,max:6,miss:13,
      absences:[
        {date:"10-03-2024",reason:"Tardanza >15 min"},
        {date:"21-03-2024",reason:"Falta injustificada"},
        {date:"04-04-2024",reason:"Falta injustificada"},
        {date:"25-04-2024",reason:"Falta injustificada"}
      ]
    }
  ]

  return (
    <section className="att-page">
      <h1>Asistencias</h1>

      <div className="period-card">
        <label>Seleccionar Período:</label>
        <select value={period} onChange={e=>setPeriod(e.target.value)}>
          <option>2024-II</option><option>2024-I</option><option>2023-II</option>
        </select>
      </div>

      <div className="att-wrapper">
        <table className="att-table">
          <thead>
            <tr>
              <th>Nº</th><th>Código</th><th>Unidad Didáctica</th>
              <th>Sesiones</th><th>Faltas perm.</th><th>% Inasist.</th><th></th>
            </tr>
          </thead>
          <tbody>
            {data.map((it,i)=><CourseRow key={it.code} idx={i} item={it}/>)}
          </tbody>
        </table>
      </div>
    </section>
  )
}
