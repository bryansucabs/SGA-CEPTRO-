import { useState } from "react"
import { FaDownload } from "react-icons/fa"

/* ------------------------------------------------------------------ */
/*  Fila de la tabla                                                   */
/* ------------------------------------------------------------------ */
function Row({ idx, item }) {
  return (
    <tr className="proc-row">
      <td>{idx + 1}</td>
      <td>{item.number}</td>
      <td>{item.name}</td>
      <td>{item.date}</td>
      <td>
        {/* ⇢ sustituye href por la URL real de tu archivo cuando conectes el backend */}
        <a href="#" download className="proc-btn">
          Descargar <FaDownload />
        </a>
      </td>
    </tr>
  )
}

/* ------------------------------------------------------------------ */
/*  Página completa                                                    */
/* ------------------------------------------------------------------ */
export default function Tramites() {
  const [period, setPeriod] = useState("2024-II")

  /* ── datos de ejemplo ──────────────────────────────────────────── */
  const data = [
    { number: "TR-2024-015", name: "Constancia de estudios", date: "05-03-2024" },
    { number: "TR-2024-068", name: "Duplicado de carnet",    date: "18-04-2024" },
    { number: "TR-2024-093", name: "Historial académico",    date: "27-04-2024" }
  ]

  return (
    <section className="proc-page">
      <h1>Trámites</h1>

      <div className="period-card">
        <label>Seleccionar Período:</label>
        <select value={period} onChange={e => setPeriod(e.target.value)}>
          <option>2024-II</option><option>2024-I</option><option>2023-II</option>
        </select>
      </div>

      <div className="proc-wrapper">
        <table className="proc-table">
          <thead>
            <tr>
              <th>Nº</th><th>Nº Trámite</th><th>Nombre de trámite</th>
              <th>Fecha solicitud</th><th></th>
            </tr>
          </thead>
          <tbody>
            {data.map((t,i)=><Row key={t.number} idx={i} item={t} />)}
          </tbody>
        </table>
      </div>
    </section>
  )
}
