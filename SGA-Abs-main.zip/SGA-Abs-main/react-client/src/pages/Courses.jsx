import { useState } from "react"
import { FaChevronDown, FaChevronUp } from "react-icons/fa"

/* ------------------------------------------------------------------ */
/*  Fila-detalle: una fila por cada sesión, alineada a las columnas    */
/* ------------------------------------------------------------------ */
function SessionRows({ sessions }) {
  return sessions.map((s, i) => (
    <tr key={i} className="course-detail">
      <td></td>              {/* Nº vacío para mantener grid */}
      <td>{s.day}</td>       {/* Día   → misma col. que Código */}
      <td>{s.time}</td>      {/* Hora  → misma col. que Unidad */}
      <td>{s.room}</td>      {/* Aula  → misma col. que Docente */}
      <td></td>              {/* botón vacío */}
    </tr>
  ))
}

/* ------------------------------------------------------------------ */
/*  Fila principal + detalle                                           */
/* ------------------------------------------------------------------ */
function CourseRow({ idx, course }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <tr className="course-row">
        <td>{idx + 1}</td>
        <td>{course.code}</td>
        <td>{course.name}</td>
        <td>{course.teacher}</td>
        <td>
          <button className="course-btn" onClick={() => setOpen(v => !v)}>
            {open ? "Ocultar" : "Ver horarios"}{" "}
            {open ? <FaChevronUp /> : <FaChevronDown />}
          </button>
        </td>
      </tr>
      {open && <SessionRows sessions={course.sessions} />}
    </>
  )
}

/* ------------------------------------------------------------------ */
/*  Página completa                                                    */
/* ------------------------------------------------------------------ */
export default function Courses() {
  const [period, setPeriod] = useState("2024-II")

  const data = [
    {
      code: "AE701",
      name: "CONTABILIDAD INTERNACIONAL",
      teacher: "Mg. Ana Torres",
      sessions: [
        { day: "Lunes",     time: "08:00-10:00", room: "A-203" },
        { day: "Miércoles", time: "08:00-10:00", room: "A-203" }
      ]
    },
    {
      code: "AE702",
      name: "ECONOMETRÍA",
      teacher: "Dr. Luis Paredes",
      sessions: [
        { day: "Martes", time: "11:00-13:00", room: "B-105" },
        { day: "Miércoles", time: "11:00-13:00", room: "B-105" }
      ]
    },
    {
      code: "AE703",
      name: "GESTIÓN DE PROYECTOS",
      teacher: "Ing. Carla Díaz",
      sessions: [
        { day: "Viernes", time: "15:00-18:00", room: "Sala Teams" }
      ]
    }
  ]

  return (
    <section className="courses-page">
      <h1>Cursos</h1>

      <div className="period-card">
        <label>Seleccionar Período:</label>
        <select value={period} onChange={e => setPeriod(e.target.value)}>
          <option>2024-II</option><option>2024-I</option><option>2023-II</option>
        </select>
      </div>

      <div className="courses-wrapper">
        <table className="courses-table">
          <thead>
            <tr>
              <th>Nº</th><th>Código</th><th>Unidad Didáctica</th><th>Docente</th><th></th>
            </tr>
          </thead>
          <tbody>
            {data.map((c, i) => <CourseRow key={c.code} idx={i} course={c} />)}
          </tbody>
        </table>
      </div>
    </section>
  )
}
