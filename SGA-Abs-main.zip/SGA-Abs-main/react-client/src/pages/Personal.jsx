import { useState } from "react"

/* ----------------------------------------------------------- */
/*  PEQUEÑO INPUT Reutilizable                                 */
/* ----------------------------------------------------------- */
function Input({ label, value, setValue, readOnly }) {
  return (
    <div className="form-row">
      <label>{label}</label>
      <input
        type="text"
        value={value}
        readOnly={readOnly}
        onChange={e => setValue && setValue(e.target.value)}
      />
    </div>
  )
}

/* ----------------------------------------------------------- */
/*  PÁGINA PRINCIPAL                                           */
/* ----------------------------------------------------------- */
export default function Personal() {

  /* ---------- estado para los campos QUE SÍ se editan ------- */

  /* Domicilio ------------- */
  const [address,setAddress]   = useState("José Abelardo Quiñones MZ31 LT3")
  const [dep,setDep]           = useState("AREQUIPA")
  const [prov,setProv]         = useState("AREQUIPA")
  const [dist,setDist]         = useState("YURA")
  const [cell,setCell]         = useState("992750135")

  /* Contacto 1 ------------- */
  const [c1Name,setC1Name]     = useState("")
  const [c1Par,setC1Par]       = useState("")
  const [c1Tel,setC1Tel]       = useState("")

  /* Contacto 2 ------------- */
  const [c2Name,setC2Name]     = useState("")
  const [c2Par,setC2Par]       = useState("")
  const [c2Tel,setC2Tel]       = useState("")

  /* Guardar (demo) */
  const handleSave = () => {
    alert("Datos guardados (demo). Aquí llamarías a tu API.")
  }

  return (
    <section className="pers-page">

      {/* ---------- DATOS GENERALES (solo lectura) ---------- */}
      <h2>Datos generales</h2>
      <div className="form-grid">
        <Input label="Nombre completo"  value="MAMANI GALDOS, PERLA SOFIA" readOnly />
        <Input label="Programa de estudio" value="ADMINISTRACIÓN DE EMPRESAS" readOnly />
        <Input label="Código"  value="79502378" readOnly />
        <Input label="DNI"     value="70892345" readOnly />
        <Input label="Sexo"    value="Femenino" readOnly />
        <Input label="Email institucional" value="perla.mamani@univ.edu.pe" readOnly />
      </div>

      {/* ---------- DOMICILIO ACTUAL ------------------------ */}
      <h2>Domicilio actual</h2>
      <div className="form-grid">
        <Input label="Dirección"    value={address} setValue={setAddress} />
        <Input label="Departamento" value={dep}     setValue={setDep} />
        <Input label="Provincia"    value={prov}    setValue={setProv} />
        <Input label="Distrito"     value={dist}    setValue={setDist} />
        <Input label="Celular / WhatsApp" value={cell} setValue={setCell} />
      </div>

      {/* ---------- CONTACTO DE EMERGENCIA ------------------ */}
      <h2>Contacto de emergencia</h2>

      {/* Contacto 1 */}
      <div className="form-grid">
        <Input label="Apellidos y nombres" value={c1Name} setValue={setC1Name}/>
        <Input label="Parentesco" value={c1Par} setValue={setC1Par}/>
        <Input label="Teléfono / celular" value={c1Tel} setValue={setC1Tel}/>
      </div>

      {/* Contacto 2 */}
      <div className="form-grid">
        <Input label="Apellidos y nombres" value={c2Name} setValue={setC2Name}/>
        <Input label="Parentesco" value={c2Par} setValue={setC2Par}/>
        <Input label="Teléfono / celular" value={c2Tel} setValue={setC2Tel}/>
      </div>

      {/* ----------- BOTÓN GUARDAR -------------------------- */}
      <div className="btn-row">
        <button className="save-btn" onClick={handleSave}>Guardar</button>
      </div>

    </section>
  )
}
